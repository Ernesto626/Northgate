﻿namespace ShoppingCartList.Blazor.Models
{
    public class UpdateShoppingCartItem
    {
        public bool Collected { get; set; }
    }
}
