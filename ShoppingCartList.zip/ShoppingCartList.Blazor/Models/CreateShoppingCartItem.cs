﻿namespace ShoppingCartList.Blazor.Models
{
    public class CreateShoppingCartItem
    {
        public string ItemName { get; set; }
    }
}
