﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCartList.Models
{
    internal class CreateShoppingCartItem
    {
        public string ItemName { get; set; }
    }
}
